import React, { useState, useEffect } from 'react'
import { ShieldCheck, TrendingDown, Clock, CheckCircle } from 'lucide-react'

export default function BookingPlatform() {
    const [pricing, setPricing] = useState({ base: 1200, current: 1200, discount: 0 })
    const [isBooking, setIsBooking] = useState(false)
    const [booked, setBooked] = useState(false)

    // Simulate Dynamic Pricing
    useEffect(() => {
        const interval = setInterval(() => {
            const fluctuation = Math.floor(Math.random() * 50) - 25 // -25 to +25
            setPricing(prev => {
                const newPrice = Math.max(800, prev.current + fluctuation)
                const discount = ((prev.base - newPrice) / prev.base * 100).toFixed(1)
                return { ...prev, current: newPrice, discount: discount > 0 ? discount : 0 }
            })
        }, 3000)
        return () => clearInterval(interval)
    }, [])

    const handleSmartContractBooking = () => {
        setIsBooking(true)
        setTimeout(() => {
            setIsBooking(false)
            setBooked(true)
        }, 2500)
    }

    return (
        <div className="container" style={{ padding: '4rem 5%', maxWidth: '900px' }}>
            <header style={{ marginBottom: '3rem', textAlign: 'center' }}>
                <h1 className="heading-xl">Web3 <span className="text-gradient">Smart Booking</span></h1>
                <p style={{ color: 'var(--text-muted)' }}>Secure, zero-fee blockchain transactions with real-time dynamic pricing.</p>
            </header>

            {booked ? (
                <div className="glass-card" style={{ textAlign: 'center', padding: '4rem 2rem' }}>
                    <CheckCircle size={64} className="text-secondary icon-pulse" style={{ margin: '0 auto 1.5rem auto' }} />
                    <h2 style={{ fontSize: '2.5rem', marginBottom: '1rem' }}>Smart Contract Executed</h2>
                    <p style={{ color: 'var(--text-muted)', marginBottom: '2rem' }}>Your itinerary has been locked on the blockchain. Have a safe adventure!</p>
                    <button className="btn btn-primary" onClick={() => setBooked(false)}>Book Another Trip</button>
                </div>
            ) : (
                <div className="glass-card">
                    <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '2rem', marginBottom: '2rem' }}>

                        {/* Dynamic Pricing Visualizer */}
                        <div style={{ padding: '1.5rem', background: 'rgba(0,0,0,0.2)', borderRadius: '1rem' }}>
                            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '1rem' }}>
                                <h3 style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
                                    <TrendingDown className="text-primary" /> Live Market Price
                                </h3>
                                <span className="text-muted" style={{ fontSize: '0.875rem' }}>Refreshes 3s</span>
                            </div>
                            <div style={{ fontSize: '3rem', fontWeight: '800', fontFamily: 'monospace', color: 'var(--secondary)' }}>
                                ${pricing.current} <span style={{ fontSize: '1rem', color: 'var(--text-muted)' }}>USDC</span>
                            </div>
                            {pricing.discount > 0 && (
                                <div style={{ color: 'var(--secondary)', fontSize: '0.875rem', marginTop: '0.5rem' }}>
                                    ↓ {pricing.discount}% demand discount applied
                                </div>
                            )}
                        </div>

                        {/* Smart Contract Info */}
                        <div style={{ padding: '1.5rem', border: '1px solid rgba(139, 92, 246, 0.3)', borderRadius: '1rem', background: 'rgba(139, 92, 246, 0.05)' }}>
                            <h3 style={{ marginBottom: '1rem', display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
                                <ShieldCheck className="text-accent" /> Verify Transaction
                            </h3>
                            <ul style={{ listStyle: 'none', color: 'var(--text-muted)', fontSize: '0.9rem', display: 'flex', flexDirection: 'column', gap: '0.5rem' }}>
                                <li><strong>Network:</strong> Ethereum L2 (Optimism)</li>
                                <li><strong>Gas Fee:</strong> ~ $0.002</li>
                                <li><strong>Escrow:</strong> 100% automated refund if cancelled 48h prior</li>
                            </ul>
                        </div>
                    </div>

                    <button
                        className="btn btn-primary"
                        style={{ width: '100%', padding: '1rem', fontSize: '1.25rem', display: 'flex', justifyContent: 'center' }}
                        onClick={handleSmartContractBooking}
                        disabled={isBooking}
                    >
                        {isBooking ? (
                            <><Clock className="icon-pulse" /> Confirming on Ledger...</>
                        ) : (
                            `Sign & Execute Booking - $${pricing.current}`
                        )}
                    </button>
                </div>
            )}
        </div>
    )
}
