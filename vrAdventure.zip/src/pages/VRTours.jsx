import React, { useState } from 'react'
import { Navigation, Maximize2, Camera } from 'lucide-react'

export default function VRTours() {
    const [activeTour, setActiveTour] = useState(null)

    const tours = [
        { id: 1, title: 'Bora Bora Overwater Bungalows', image: 'https://images.unsplash.com/photo-1502008479536-ee1b321420d9?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80', price: '$1200' },
        { id: 2, title: 'Swiss Alps Ski Resort', image: 'https://images.unsplash.com/photo-1551524164-687a55dd1126?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80', price: '$850' },
        { id: 3, title: 'Kyoto Ancient Temples', image: 'https://images.unsplash.com/photo-1493976040374-85c8e12f0c0e?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80', price: '$920' },
    ]

    return (
        <div className="container" style={{ padding: '2rem 5%' }}>
            <header style={{ marginBottom: '3rem', textAlign: 'center' }}>
                <h1 className="heading-xl">Immersive <span className="text-gradient">VR Tours</span></h1>
                <p style={{ color: 'var(--text-muted)' }}>Step into your destination before booking. Compatible with WebXR and mobile headsets.</p>
            </header>

            {activeTour ? (
                <div className="vr-viewer glass-card" style={{ position: 'relative', height: '600px', overflow: 'hidden', padding: 0 }}>
                    {/* Simulated VR Iframe or 360 Viewer */}
                    <div style={{
                        position: 'absolute', top: 0, left: 0, right: 0, bottom: 0,
                        backgroundImage: `url(${activeTour.image})`,
                        backgroundSize: 'cover',
                        backgroundPosition: 'center',
                        filter: 'brightness(0.7)'
                    }}></div>

                    <div style={{ position: 'absolute', top: '20px', left: '20px', zIndex: 10 }}>
                        <button className="btn btn-outline" style={{ background: 'rgba(0,0,0,0.5)', borderColor: 'transparent' }} onClick={() => setActiveTour(null)}>
                            Exit VR
                        </button>
                    </div>

                    <div style={{ position: 'absolute', top: '50%', left: '50%', transform: 'translate(-50%, -50%)', textAlign: 'center', zIndex: 10 }}>
                        <Maximize2 size={64} className="icon-pulse" style={{ color: 'rgba(255,255,255,0.8)', marginBottom: '1rem' }} />
                        <h2 style={{ fontSize: '2rem', textShadow: '0 2px 4px rgba(0,0,0,0.5)' }}>{activeTour.title}</h2>
                        <p style={{ textShadow: '0 1px 2px rgba(0,0,0,0.5)' }}>Drag to look around (Simulation)</p>
                    </div>
                </div>
            ) : (
                <div className="grid-3">
                    {tours.map(tour => (
                        <div key={tour.id} className="glass-card" style={{ padding: '1rem' }}>
                            <div style={{
                                height: '200px',
                                borderRadius: '0.5rem',
                                backgroundImage: `url(${tour.image})`,
                                backgroundSize: 'cover',
                                backgroundPosition: 'center',
                                marginBottom: '1rem'
                            }}></div>
                            <h3 style={{ fontSize: '1.25rem', marginBottom: '0.5rem' }}>{tour.title}</h3>
                            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '1rem' }}>
                                <span className="text-gradient" style={{ fontWeight: 'bold' }}>{tour.price}</span>
                                <span style={{ fontSize: '0.875rem', color: 'var(--text-muted)' }}>Dynamic Avg</span>
                            </div>
                            <button className="btn btn-primary" style={{ width: '100%' }} onClick={() => setActiveTour(tour)}>
                                <Navigation size={18} /> Enter Tour
                            </button>
                        </div>
                    ))}
                </div>
            )}
        </div>
    )
}
