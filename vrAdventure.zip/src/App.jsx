import React from 'react'
import { BrowserRouter as Router, Routes, Route, Link } from 'react-router-dom'
import { Compass, Book, User, Settings } from 'lucide-react'
import Home from './pages/Home'
import VRTours from './pages/VRTours'
import BookingPlatform from './pages/BookingPlatform'
import './index.css'

function App() {
  return (
    <Router>
      <div className="min-h-screen app-container">
        {/* Modern Navbar */}
        <nav className="navbar">
          <div className="nav-brand">
            <Compass size={28} className="icon-pulse text-primary" />
            <span className="brand-text">vrAdventure</span>
          </div>
          <div className="nav-links">
            <Link to="/" className="nav-link">Home</Link>
            <Link to="/vr-tours" className="nav-link">VR Tours</Link>
            <Link to="/booking" className="nav-link">Booking</Link>
          </div>
        </nav>

        {/* Main Content Area */}
        <main className="main-content">
          <Routes>
            <Route path="/" element={<Home />} />
            <Route path="/vr-tours" element={<VRTours />} />
            <Route path="/booking" element={<BookingPlatform />} />
          </Routes>
        </main>
      </div>
    </Router>
  )
}

export default App
